library(testthat)
library(newscatcheR)

test_check("newscatcheR")
