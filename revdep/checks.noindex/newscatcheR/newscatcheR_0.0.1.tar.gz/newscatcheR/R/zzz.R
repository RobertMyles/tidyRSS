#' @import utils
utils::globalVariables("rss_table")
