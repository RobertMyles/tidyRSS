# newcatcheR 0.0.1

* First release.

* Added a `NEWS.md` file to track changes to the package.
